/*
 * Maintain Scroll Position in any Page Element
 * http://authors.aspalliance.com/jimross/Articles/MaintainScrollPos.aspx
 * 
 * Remember a Div's Scroll Position
 * http://radio.javaranch.com/pascarello/2005/07/18/1121709316718.html
 */
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        System.Collections.ArrayList lst = new System.Collections.ArrayList();
        lst.Add("Chateau Lafite Rothschild, 1959");
        lst.Add("Chateau Mouton Rothschild, 1945");
        lst.Add("Maddog 'da Ripper, yesterday");
        lst.Add("Penfolds Grange, 1981");
        lst.Add("Patricia Green Cellars, Estate Pinot Noir, 2000");
        lst.Add("Owen Roe Pinot Gris, 2001");
        lst.Add("d'Arenberg Dead Arm Shiraz, 1978");
        lst.Add("Adelsheim Chardonnay, Elizabeth's Reserve, 1989");
        lst.Add("Screaming Eagle, 1998");
        lst.Add("Far Niente Chardonnay, 2002, 'why pay less?'");
        lst.Add("Vieux Telegraphe CnDP, 1989");
        lst.Add("Whennler Sonnenur Auselese, J.J.Prum, 1978");

        this.dgOne.DataSource = lst;
        this.dgOne.DataBind();
        this.dgTwo.DataSource = lst;
        this.dgTwo.DataBind();
        
    }
}
